<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Example Moodle Language String.
 *
 * @package   local_xapireport
 * @copyright 2018 PosBoss IT
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['xapireport:view'] = 'xAPI 分析報表';
$string['welcome'] = '歡迎使用 xAPI 報表';
$string['xapireport'] = '歡迎使用 xAPI 報表, {$a}!';
$string['pluginname'] = 'xAPI分析報表外掛';
$string['reportname']='xAPI分析報表';
$string['email']='輸入 Email:';
$string['course_name']='請選擇教材活動:';
$string['user_name']='請選擇使用者:';
$string['from']='請選擇開始時間:';
$string['to']='請選擇結束時間:';
$string['passed']='成功或失敗(結果):';
$string['local_xapireport_setting']='xAPI分析報表外掛設定:';
$string['heading']='一般設定:';
$string['xapireportcat']='xAPI分析報表外掛設定';
$string['description']='xAPI 外掛:';
$string['descriptionofreport']='xAPI 外掛: 學習歷程分析報表';
$string['foo']='xAPI 報表連結';

