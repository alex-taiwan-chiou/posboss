<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Links and settings
 *
 * Contains settings used by logs report.
 *
 * @package    report_log
 * @copyright  1999 onwards Martin Dougiamas (http://dougiamas.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;
if ($hassiteconfig){
// Just a link to course report.
$ADMIN->add('reports', new admin_externalpage('hello', get_string('reportname','local_xapireport'),
        $CFG->wwwroot."/local/xapireport/index.php"));

// Report Plugin settings.
//$setting=null;
$settings = new admin_settingpage('local_xapireport',get_string('local_xapireport_setting','local_xapireport'));
$settings->add(new admin_setting_heading('local_xapireport/generalheading',get_string('heading','local_xapireport'),''));
//$ADMIN->add('local', new admin_category('xapireport', get_string('xapireportcat', 'local_xapireport')));
$settings->add(new admin_setting_configtext('local_xapireport/xapiurl','xAPI URL:','This is url of LL2 aggregation api',
               'http://localhost/api/statements/aggregate?pipeline=',PARAM_TEXT,'66'));
$settings->add(new admin_setting_configtextarea('local_xapireport/pipeline','Pipeline Stage:','This is Pipeline stages for aggregating statements from LL2',
               '[{"$sort":{"statement.timestamp": -1}},{"$limit":88888},{"$project":{"statements":"$statement"}}]',PARAM_TEXT,'80','10'));
$settings->add( new admin_setting_configtextarea(
 
		// This is the reference you will use to your configuration
		'local_xapireport/apikey',
 
		// This is the friendly title for the config, which will be displayed
		'xAPI 授權密碼:',
 
		// This is helper text for this config field
		'This is the basic authorization token used to access the External REST API',
 
		// This is the default value
		'YmYzMmU2NDZlNWVmNmUxNTNiMWU3NjNjNmUwZjc1ZTJlNmI0YjVmYjo0NjE1ZDA3Yzk4NzVhN2FkMDNmOTFlZGQ4ZTVkMGUzODljYzEwNmYx',
 
		// This is the type of Parameter this config is
		PARAM_TEXT,'80','10'
 
	) );
$ADMIN->add('localplugins',$settings);
}