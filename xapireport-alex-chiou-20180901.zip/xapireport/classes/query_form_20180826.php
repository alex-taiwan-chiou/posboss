<?php
//moodleform is defined in formslib.php
require_once("$CFG->libdir/formslib.php");
require_once( $CFG->dirroot . '/config.php');

class alex_chiou extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
		global $DB;
        //$courselist = get_courses();
		//$finalcourses[0]='all';
		//$i=1;
		//foreach ($courselist as $mdlCourse){
		//	$finalcourses[$i]=$mdlCourse->fullname;
		//	$i=$i+1;
		//}
		//$i=0;
		// get uploaded courses 		
		$finalcourses = array('all'=>'all','TalkMaster_001'=>'TalkMaster_001','TalkMaster_002'=>'TalkMaster_002','TalkMaster_003'=>'TalkMaster_003');
		//get enrolled users
		$finalUsers = array('all'=>'all','Email@xxxx.com.tw'=>'Email@xxxx.com.tw','amber@posboss.com.tw'=>'amber@posboss.com.tw','taco168@posboss.com.tw'=>'taco168@posboss.com.tw','chiou@posboss.com.tw'=>'chiou@posboss.com.tw');
		//$userlist=$DB->get_records_sql('SELECT email FROM mdl_user');
        // foreach ($userlist as $mdlUser){
		//	$finalUsers[$i]=$mdlUser->email;
		//	$i=$i+1;
		//}
		//$passedorfailed = array("passed"=>"passed","failed"=>"failed");
		
		//print_r($finalUsers);
        $mform = $this->_form; // Don't forget the underscore! 
      
       
		// select user name
		$select1 = $mform->addElement('select', 'user', get_string('user_name','local_xapireport'), $finalUsers);
        $select1->setSelected('all');        //Default value 
		//select course name
        $select2 = $mform->addElement('select', 'course', get_string('course_name','local_xapireport'), $finalcourses);
		$select2->setSelected('all');        //Default value  
        // select the context--result
       // $select3 = $mform->addElement('select', 'passed', get_string('passed','local_xapireport'), $passedorfailed);
		
		// set duration
		//$mform->addElement('date_time_selector', 'startTime', get_string('from','local_xapireport'));
		//$mform->addElement('date_time_selector', 'endTime', get_string('to','local_xapireport'));
        $this->add_action_buttons();		
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}