<?php
//moodleform is defined in formslib.php
require_once("$CFG->libdir/formslib.php");
require_once( $CFG->dirroot . '/config.php');

class query_form extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
		global $DB;
        //$courselist = get_courses();
		//$finalcourses[0]='all';
		//$i=1;
		//foreach ($courselist as $mdlCourse){
		//	$finalcourses[$i]=$mdlCourse->fullname;
		//	$i=$i+1;
		//}
		//$i=0;
		// get uploaded courses 		
		$finalcourses = array('all'=>'all','TalkMaster_001'=>'TalkMaster_001','TalkMaster_002'=>'TalkMaster_002','TalkMaster_003'=>'TalkMaster_003');
		//get enrolled users
		$finalUsers = array('all'=>'all','Email@xxxx.com.tw'=>'Email@xxxx.com.tw','amber@posboss.com.tw'=>'amber@posboss.com.tw','taco168@posboss.com.tw'=>'taco168@posboss.com.tw','chiou@posboss.com.tw'=>'chiou@posboss.com.tw');
		//$userlist=$DB->get_records_sql('SELECT email FROM mdl_user');
        // foreach ($userlist as $mdlUser){
		//	$finalUsers[$i]=$mdlUser->email;
		//	$i=$i+1;
		//}
		//$passedorfailed = array("passed"=>"passed","failed"=>"failed");
		
		//print_r($finalUsers);
        $mform = $this->_form; // Don't forget the underscore! 
        $title_form = '<h1>'.get_string('descriptionofreport','local_xapireport').'</h1><br>';
		//var_dump($title_form);
        $mform->addElement('html', $title_form);
		// select user name
		$select1 = $mform->addElement('select', 'user', get_string('user_name','local_xapireport'), $finalUsers);
        $select1->setSelected('all');        //Default value 
		//select course name
        $select2 = $mform->addElement('select', 'course', get_string('course_name','local_xapireport'), $finalcourses);
		$select2->setSelected('all');        //Default value  
        // select the context--result
       // $select3 = $mform->addElement('select', 'passed', get_string('passed','local_xapireport'), $passedorfailed);
		
		// set duration
		$def_date_time1= array(
             'startyear' => 2018, 
             'stopyear'  => 2020,
			 'defaulttime'=> null,
             'timezone'  => 'Asia/Taipei',
			 'step'=>1,
             'optional'  => true
         );
		 $def_date_time2= array(
             'startyear' => 2018, 
             'stopyear'  => 2020,
			 'defaulttime'=> null,
             'timezone'  => 'Asia/Taipei',
			 'step'=>1,
             'optional'  => true
         );
		$select3=$mform->addElement('date_time_selector', 'startTime', get_string('from','local_xapireport'),$def_date_time1);
		
		$select4=$mform->addElement('date_time_selector', 'endTime', get_string('to','local_xapireport'),$def_date_time2);
        
		$this->add_action_buttons();		
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}