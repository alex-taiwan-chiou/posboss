<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * An example of a stand-alone Moodle script.
 *
 * @package   local_xapireport
 * @copyright 2018 PosBoss IT
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


require_once(dirname(__FILE__) . '/../../config.php');        


require_login();                                           
$context = context_system::instance();                        
require_capability('local/xapireport:view', $context);        

$name = optional_param('name', '', PARAM_TEXT);               
if (!$name) {
    $name = fullname($USER);                                  
}

add_to_log(SITEID, 'local_xapireport', 'view',
        'local/xapireport/index.php?name=' . urlencode($name));    

$PAGE->set_context($context);                                 
$PAGE->set_url(new moodle_url('/local/xapireport/index.php'),
        array('name' => $name));                              
$PAGE->set_title(get_string('welcome', 'local_xapireport'));       

//declare globale variables for the filters of statements
$actorFilter = "all";
$courseFilter = "all";
$resultFilter = "all";
$startTimeFilter="all";
$endTimeFilter="all";
$new_pipeline = null;
echo $OUTPUT->header();

//include filters in a moodle_form

require_once(dirname(__FILE__) . '/classes/query_form.php');
//date_default_timezone_set('Asia/Taipei');
//Instantiate moodle_form 
$mform = new query_form();
$fromForm = array(
            "course" => "all",
			"user" => "all",
			"startTime"=>null,
			"endTime"=>null,
			); 
$toForm = array(
            "course"=>null,
			"user"=>null,
			"startTime"=>null,
			"endTime"=>null,			
			);

//Form processing and displaying is done here
if ($mform->is_cancelled()) {
    //Handle form cancel operation, if cancel button is present on form
} else if ($toForm = $mform->get_data()) {
  //In this case you process validated data. $mform->get_data() returns data posted in form.
  //echo '<B>'.$fromForm.'</B>'.;
  // pass the filters of $toForm to action.php
  $myTimeZone = new DateTimeZone('Asia/Taipei');
  $gmtTimeZone = new DateTimeZone('GMT');
  $sTime = $toForm->startTime;
  $eTime = $toForm->endTime;
  
  //var_dump($toForm->startTime);
  //var_dump($toForm->endTime);
  if ($sTime!=0){
  $start_time = date('Y-m-d H:i:s',$toForm->startTime);
  $start_time_new = new DateTime($start_time,$myTimeZone);
  $start_time_new->setTimezone($gmtTimeZone);
  $sTime_temp1 = $start_time_new->format('Y-m-d H:i:s');
  $sTime_temp2 = explode(' ',$sTime_temp1);
  $sTime_new = $sTime_temp2[0].'T'.$sTime_temp2[1];
  }
  if ($eTime!=0){
  $end_time = date('Y-m-d H:i:s',$toForm->endTime);
  $end_time_new = new DateTime($end_time,$myTimeZone);
  $end_time_new->setTimezone($gmtTimeZone);
  $eTime_temp1 = $end_time_new->format('Y-m-d H:i:s');
  $eTime_temp2 = explode(' ',$eTime_temp1);
  $eTime_new = $eTime_temp2[0].'T'.$eTime_temp2[1];
  }
  var_dump($toForm->user);
  var_dump($toForm->course);
  var_dump($sTime_new);
  var_dump($eTime_new);
  if ($toForm->user=='all'&&$toForm->course=='all'&&($sTime==0)&&($eTime==0)){
	  echo "Situation 1.....";
      // Do Nothing!
	  //var_dump($new_pipeline);
  }
  
  if ($toForm->user!=='all'&&$toForm->course=='all'&&($sTime==0)&&($eTime==0)){
	  echo "Situation 2.....";
      $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'"}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  //var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course!=='all'&&($sTime==0)&&($eTime==0)){
	  echo "Situation 3.....";
      $xapi_match_part =',{"$match":{"statement.object.id":{"$regex":"/'.$toForm->course.'/"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	 // var_dump($new_pipeline);
  }
  if ($toForm->user!=='all'&&$toForm->course!=='all'&&($sTime==0)&&($eTime==0)){
	  echo "Situation 4.....";
	  $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.object.id":{"$regex":"/'.$toForm->course.'/"}}}';
      //$xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.',"statement.object.id":"'.$toForm->course.'"}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  //var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course=='all'&&($sTime!=0)&&($eTime==0)){
	  echo "Situation 5.....";
      $xapi_match_part =',{"$match":{"statement.timestamp":{"$gte":"'.$sTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  
  if ($toForm->user!=='all'&&$toForm->course=='all'&&($sTime!=0)&&($eTime==0)){
	  echo "Situation 6.....";
      $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.timestamp":{"$gte":"'.$sTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course!=='all'&&($sTime!=0)&&($eTime==0)){
	  echo "Situation 7....";
      $xapi_match_part =',{"$match":{"statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$gte":"'.$sTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user!=='all'&&$toForm->course!=='all'&&($sTime!=0)&&($eTime==0)){
	  echo "Situation 8.....";
	  $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$gte":"'.$sTime_new.'"}}}';
      //$xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.',"statement.object.id":"'.$toForm->course.'"}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course=='all'&&($sTime==0)&&($eTime!=0)){
	  echo "Situation 9.....";
      $xapi_match_part =',{"$match":{"statement.timestamp":{"$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  
  if ($toForm->user!=='all'&&$toForm->course=='all'&&($sTime==0)&&($eTime!=0)){
	  echo "Situation 10.....";
      $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.timestamp":{"$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course!=='all'&&($sTime==0)&&($eTime!=0)){
	  echo "Situation 11.....";
      $xapi_match_part =',{"$match":{"statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user!=='all'&&$toForm->course!=='all'&&($sTime==0)&&($eTime!=0)){
	  echo "Situation 12.....";
	  $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$lte":"'.$eTime_new.'"}}}';
      //$xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.',"statement.object.id":"'.$toForm->course.'"}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course=='all'&&($sTime!=0)&&($eTime!=0)){
	  echo "Situation 13.....";
      $xapi_match_part =',{"$match":{"statement.timestamp":{"$gte":"'.$sTime_new.'","$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  
  if ($toForm->user!=='all'&&$toForm->course=='all'&&($sTime!=0)&&($eTime!=0)){
	  echo "Situation 14.....";
       $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.timestamp":{"$gte":"'.$sTime_new.'","$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user=='all'&&$toForm->course!=='all'&&($sTime!=0)&&($eTime!=0)){
	  echo "Situation 15....";
      $xapi_match_part =',{"$match":{"statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$gte":"'.$sTime_new.'","$lte":"'.$eTime_new.'"}}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  if ($toForm->user!=='all'&&$toForm->course!=='all'&&($sTime!=0)&&($eTime!=0)){
	  echo "Situation 16.....";
	  $xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.'","statement.object.id":{"$regex":"/'.$toForm->course.'/"},"statement.timestamp":{"$gte":"'.$sTime_new.'","$lte":"'.$eTime_new.'"}}}';
      //$xapi_match_part =',{"$match":{"statement.actor.mbox":"mailto:'.$toForm->user.',"statement.object.id":"'.$toForm->course.'"}}';
	  $temp_config = get_config('local_xapireport');
      $xapi_part_array = explode('}}',$temp_config->pipeline);
	  $new_pipeline = $xapi_part_array[0].'}}'.$xapi_match_part.$xapi_part_array[1].'}}'.$xapi_part_array[2];
	  var_dump($new_pipeline);
  }
  
  
  //var_dump($toForm);
  require_once(dirname(__FILE__) . '/newpage/action.php');
  
  // output to Moodle html_table()
  $table = new html_table();
  $table->head = array("name","mbox","ob_id","activity title","activity type","time stamp", "stored time", "scene sort","scene index","conversation","verb","response","result","score");
  // print out $mystatements
  //print_r($returnArray);
  $table->data= $returnArray;
  echo html_writer::table($table);
  echo '<a href="xapiReport.csv">下載 CSV</a>　　　<a href="index.php">回主頁</a>　Copyright © 2018 PosBoss IT All rights reserved';
} else {
  // this branch is executed if the form is submitted but the data doesn't validate and the form should be redisplayed
  // or on the first display of the form.
  //$def_date_time = new stdClass();
  //$def_date_time->startTime = mktime(0,0,0,8,30,2018);
  //$def_date_time->endTime =mktime(0,0,0,12,31,2020);
  //Set default data (if any)
  $mform->set_data($fromForm);
  
  //displays the form
  $mform->display();
 
}


echo $OUTPUT->footer();                                       // 13
