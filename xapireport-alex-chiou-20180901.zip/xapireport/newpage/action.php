<?php
/**
 * Example Moodle script version information.
 *
 * @package   local_xapireport
 * @copyright 2018 PosBoss IT
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
//$xapiSort = '[{"$sort":{"statement.timestamp":-1,"statement.actor.mbox":1}},';
//$xapiProject = '{"$limit":88888},{"$project":{"statements":"$statement"}}]'; 
$xapi_config = get_config('local_xapireport');

//$url_pipeline = '[{"$sort":{"statement.timestamp":-1}},{"$limit":88888},{"$project":{"statements":"$statement"}}]';
if (!isset($new_pipeline)){
$url_pipeline = $xapi_config->pipeline ;
}
else {
	$url_pipeline=$new_pipeline;
}
//var_dump($url_pipeline);
$url_pipeline_encode = urlencode($url_pipeline);
$xapi_para = $xapi_config->xapiurl.$url_pipeline_encode;
//var_dump($xapi_para);
//$xapi_para = "http://lrs.posboss.com.tw/api/statements/aggregate?pipeline=".$url_pipeline_encode;
//global variables
$returnArray=array();
$content = request($xapi_para,$xapi_config);
//var_dump($content);
convertToCSV($content);
// setting connection
function request($url,$xapi_config) {
	//var_dump($xapi_config->apikey);
    $ch = curl_init();
    $curlOpts = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array(
            //"Authorization: Basic YTdkZGQ3MWQ4ODA4M2JmZTI4NDY5ZmUwMDE1YjI0MTVhOTZhMGI0ZToyYTNlM2MzNTA4NjNjM2IwY2U4NGMxNmRhNjNlYWMzYzlhNmFmOGU4",
			"Authorization: Basic ".$xapi_config->apikey,
            "X-Experience-API-Version: 1.0.3"
        ),
        CURLOPT_FOLLOWLOCATION => true
    );
    curl_setopt_array($ch, $curlOpts);
    $answer = curl_exec($ch);
    // If there was an error, show it
    if (curl_error($ch)) die(curl_error($ch));
    curl_close($ch);
    return $answer;
}
// getting data from json object
function convertToCSV($content) {
	global $actorFilter;
	global $courseFilter;
	global $resultFilter;
	global $startTimeFilter;
	global $endTimeFilter;
	global $returnArray;
	$array = json_decode($content, true);
	for ($k=0;$k<count($array);$k++){
	$statements = $array[$k]["statements"];
	//var_dump($statements);break;
        
        $temp = array();
        // array_push($temp, $statements['id']);
        $actor = $statements['actor'];
        array_push($temp, $actor['name']);
        $email = explode(":", $actor['mbox']);
        array_push($temp, $email[1]);
        //array_push($temp, $actor['objectType']);
        $start_time = str_replace("T", " ", $statements['timestamp']);
        $start_time = explode(".", $start_time);
        $end_time = str_replace("T", " ", $statements['stored']);
        $end_time = explode(".", $end_time);
		
		  // set time zone for start time
        $userTimeZone = new DateTimeZone('Asia/Taipei');
        $GMT = new DateTimeZone('GMT');

        $start = new DateTime($start_time[0], $GMT);
        $start->setTimezone($userTimeZone);
        $first = $start->format('Y-m-d H:i:s');
        // set time zone for end time
        $end = new DateTime($end_time[0], $GMT);
        $end->setTimezone($userTimeZone);
        $second = $end->format('Y-m-d H:i:s');
        //var_dump($first);exit(0);
		
        $object = $statements['object'];
        $def = $object['definition'];
		$def_type = explode('http://adlnet.gov/expapi/activities/',$def['type']);
        $title = "";
        if (array_key_exists("name", $def)) {
            $title = $def['name'];
            $title = $title['und'];
        }
		array_push($temp, $object['id']);
        array_push($temp, $title);
		array_push($temp, $def_type[1]);
        array_push($temp, $first);
        array_push($temp, $second);
		
        // part 2
        $scene = $statements['object']['id'];
		//$ispringCourse = explode('ispring://presentations/',$scene);
		//var_dump($ispringCourse);
        $s = explode ('/', $scene);
        $sc = explode ('_', $s[count($s) - 1]);
		//var_dump($s);
		//var_dump($sc);
        if (count($sc) == 2 && $sc[0] !=='s') {
            array_push($temp, $sc[1]);
			array_push($temp, $sc[0]);
        } else {
            array_push($temp, 0);
            array_push($temp, 0);
        }
        $message = "";
        if (array_key_exists('description', $statements['object']['definition'])) {
             $message = $statements['object']['definition']['description']['und'];
        }
        $v = $statements['verb']['display']['en-US'];
        array_push($temp, $message);
        array_push($temp, $v);
        if ($v == "responded") {
            $choice = $statements['result']['response'];
            for ($j = 0; $j < count($statements['object']['definition']['choices']); $j++) {
                if ($statements['object']['definition']['choices'][$j]['id'] == $choice) {
                    $choice_str = $statements['object']['definition']['choices'][$j]['description']['und'];
                    array_push($temp, $choice_str);
                    break;
                }
            }
        } else {
            array_push($temp, ' ');
        }
        if (array_key_exists("result", $statements) && (array_key_exists("score", $statements['result']))) {
            if ($statements['result']['score']['scaled'] == 1) {
                $result = 'true';
            } else if ($statements['result']['score']['scaled'] == 0) {
                $result = 'false';
            } else {
                $result = ' ';
            }
            array_push($temp, $result);
            $score = $statements['result']['score']['raw'];
            array_push($temp, $score);
        } else {
            array_push($temp, '');
            array_push($temp, 0);
        }
        array_push($returnArray, $temp);
	}
    convertHelper($returnArray);
}
function convertHelper($returnArray) {
     // convert to CSV file
    $fileName = "xapiReport.csv";
    header("Content-Type: text/csv");
    header('Content-Disposition: attachment; filename=output.csv');
    $output = fopen($fileName, 'w');
    // convert garbage code to Chinese characters
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    $columnHeader = array("name","mbox","ob_id","activity title","activity type","time stamp", "stored time", "scene sort","scene index","conversation","verb","response","result","score");
    fputcsv($output, $columnHeader);
    foreach ($returnArray as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
}
?>
