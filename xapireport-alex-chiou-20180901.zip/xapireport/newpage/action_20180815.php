<?php
$content = request("http://lrs.posboss.com.tw/data/xAPI/statements");
$returnArray=array();
convertToCSV($content,$returnArray);
// setting connection
function request($url) {
    $ch = curl_init();
    $curlOpts = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Basic YTdkZGQ3MWQ4ODA4M2JmZTI4NDY5ZmUwMDE1YjI0MTVhOTZhMGI0ZToyYTNlM2MzNTA4NjNjM2IwY2U4NGMxNmRhNjNlYWMzYzlhNmFmOGU4",
            "X-Experience-API-Version: 1.0.3"
        ),
        CURLOPT_FOLLOWLOCATION => true
    );
    curl_setopt_array($ch, $curlOpts);
    $answer = curl_exec($ch);
    // If there was an error, show it
    if (curl_error($ch)) die(curl_error($ch));
    curl_close($ch);
    return $answer;
}
// getting data from json object
function convertToCSV($content) {
	global $actorFilter;
	global $courseFilter;
	global $resultFilter;
	global $startTimeFilter;
	global $endTimeFilter;
	
    $array = json_decode($content, true);
    $statements = $array["statements"];  
    for ($i = 0; $i < count($statements); $i++) {
        $temp = array();
		global $returnArray;
        // array_push($temp, $statements[$i]['id']);
        $actor = $statements[$i]['actor'];
        array_push($temp, $actor['name']);
        $email = explode(":", $actor['mbox']);
		//check if $actorFilter pass?
		if (!($email[1]===$actorFilter)){continue;}
		
        array_push($temp, $email[1]);
        array_push($temp, $actor['objectType']);
        $start_time = str_replace("T", " ", $statements[$i]['timestamp']);
        $start_time = explode(".", $start_time);
        $end_time = str_replace("T", " ", $statements[$i]['stored']);
        $end_time = explode(".", $end_time);
       
        $time1 = strtotime($start_time[0]);
        $time2 = strtotime($end_time[0]);
         // set time zone for start time
        $userTimeZone = new DateTimeZone('Asia/Taipei');
        $GMT = new DateTimeZone('GMT');

        $start = new DateTime($start_time[0], $GMT);
        $start->setTimezone($userTimeZone);
        $first = $start->format('Y-m-d H:i:s');
        // set time zone for end time
        $end = new DateTime($end_time[0], $GMT);
        $end->setTimezone($userTimeZone);
        $second = $end->format('Y-m-d H:i:s');

        $time_diff = $time2 - $time1;
        $object = $statements[$i]['object'];
        $def = $object['definition'];
        $title = "";
        if (array_key_exists("name", $def)) {
            $title = $def['name'];
            $title = $title['und'];
        }
        array_push($temp, $title);
        array_push($temp, $first);
        array_push($temp, $second);
        array_push($temp, $time_diff);
        // part 2
        $scene = $statements[$i]['object']['id'];
        $s = explode ('/', $scene);
        $sc = explode ('_', $s[count($s) - 1]);
        if (count($sc) == 2 && $sc[0] !=='s') {
            array_push($temp, $sc[0]);
            array_push($temp, $sc[1]);
        } else {
            array_push($temp, 0);
            array_push($temp, 0);
        }
        $message = "";
        if (array_key_exists('description', $statements[$i]['object']['definition'])) {
             $message = $statements[$i]['object']['definition']['description']['und'];
        }
        $v = $statements[$i]['verb']['display']['en-US'];
        array_push($temp, $message);
        array_push($temp, $v);
        if ($v == "responded") {
            $choice = $statements[$i]['result']['response'];
            for ($j = 0; $j < count($statements[$i]['object']['definition']['choices']); $j++) {
                if ($statements[$i]['object']['definition']['choices'][$j]['id'] == $choice) {
                    $choice_str = $statements[$i]['object']['definition']['choices'][$j]['description']['und'];
                    array_push($temp, $choice_str);
                    break;
                }
            }
        } else {
            array_push($temp, ' ');
        }
        if (array_key_exists("result", $statements[$i]) && (array_key_exists("score", $statements[$i]['result']))) {
            if ($statements[$i]['result']['score']['scaled'] == 1) {
                $result = 'true';
            } else if ($statements[$i]['result']['score']['scaled'] == 0) {
                $result = 'false';
            } else {
                $result = ' ';
            }
            array_push($temp, $result);
            $score = $statements[$i]['result']['score']['raw'];
            array_push($temp, $score);
        } else {
            array_push($temp, '');
            array_push($temp, 0);
        }
        array_push($returnArray, $temp);
    }
    convertHelper($returnArray);
}
function convertHelper($returnArray) {
     // convert to CSV file
    $fileName = "output.csv";
    header("Content-Type: text/csv");
    header('Content-Disposition: attachment; filename=output.csv');
    $output = fopen($fileName, 'w+');
    // convert garbage code to Chinese characters
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    $columnHeader = array("name","Email","client","title","starting time", "ending time", "time diff(second)", "scene_sort","scene_index","conversation","verb","text","answer","score");
    fputcsv($output, $columnHeader);
    foreach ($returnArray as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
}
?>

